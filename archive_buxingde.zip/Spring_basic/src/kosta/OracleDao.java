package kosta;

public class OracleDao implements Dao {

}
