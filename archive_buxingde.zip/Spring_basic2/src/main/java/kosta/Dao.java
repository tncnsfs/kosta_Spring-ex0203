package kosta;

public interface Dao {
	void insertBoard();
}
