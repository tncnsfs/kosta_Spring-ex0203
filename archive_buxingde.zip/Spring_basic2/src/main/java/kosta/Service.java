package kosta;

public interface Service {
	public void insert();
}
