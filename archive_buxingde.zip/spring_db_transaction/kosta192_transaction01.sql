--
--create table order2(
--  no varchar2(20),
--  name varchar2(20),
--  price number,
--  amount number	
--)
--
--create table item(
--  no varchar2(20),
--  name varchar2(20),
--  price number,
--  amount number
--  
--)
--
insert into item values('100', 'pc', 50000, 100);


  
