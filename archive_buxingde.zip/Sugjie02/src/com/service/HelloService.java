package com.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {

	public String getMessage(){
	 return "Hello Spring2!!!";
	}
}
