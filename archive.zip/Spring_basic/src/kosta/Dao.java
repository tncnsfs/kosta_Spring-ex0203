package kosta;

public interface Dao {

}
